`node /data/data/com.termux/files/home/whatsapp-bot/index.js`
